<?php
/**
* The main entry class for calling core classes.
* ºscr
*/
require(dirname(__FILE__).'/AppBase.php');

class App extends AppBase{}