CREATE TABLE IF NOT EXISTS `users` (
  id bigint(20) NOT NULL PRIMARY KEY AUTO_INCREMENT,
  email VARCHAR(100) NOT NULL,
  password VARCHAR(64),
  type TINYINT(1) DEFAULT 1,
  first_name VARCHAR(50),
  last_name VARCHAR(50),
  address VARCHAR(250),
  city VARCHAR(50),
  state VARCHAR(50),
  postal_code CHAR(10),
  country CHAR(3),
  phone VARCHAR(20),
  date_created DATETIME DEFAULT '0000-00-00',
  status TINYINT(1) DEFAULT 1,
  INDEX(email)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `users_hashes` (
	id bigint(20) NOT NULL PRIMARY KEY AUTO_INCREMENT,
	email_or_id VARCHAR(100) NOT NULL,
	hash CHAR(64),
	type TINYINT(1) DEFAULT 1,
	date_created DATETIME DEFAULT '0000-00-00',
	status TINYINT(1) DEFAULT 0,
	INDEX(hash)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `organization` (
	id INT(10) NOT NULL PRIMARY KEY AUTO_INCREMENT,
	user_id bigint(20) NOT NULL,
	name VARCHAR(50) NOT NULL,
	description TINYTEXT  DEFAULT NULL,
	date_created DATETIME DEFAULT '0000-00-00',
	INDEX(user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `organization_members` (
	id INT(10) NOT NULL PRIMARY KEY AUTO_INCREMENT,
	organization_id INT(10) NOT NULL,
	user_id bigint(20) NOT NULL,
	role_id TINYINT(2) DEFAULT 1,
	date_joined DATETIME DEFAULT '0000-00-00',
	status TINYINT(1) DEFAULT 1,
	INDEX(user_id),INDEX(organization_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `project` (
	id INT(10) NOT NULL PRIMARY KEY AUTO_INCREMENT,
	user_id bigint(20) NOT NULL,
	name VARCHAR(50) NOT NULL,
	description TINYTEXT  DEFAULT NULL,
	date_created DATETIME DEFAULT '0000-00-00',
	INDEX(user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `project_members` (
	id INT(10) NOT NULL PRIMARY KEY AUTO_INCREMENT,
	project_id INT(10) NOT NULL,
	user_id bigint(20) NOT NULL,
	role_id TINYINT(2) DEFAULT 1,
	date_joined DATETIME DEFAULT '0000-00-00',
	status TINYINT(1) DEFAULT 1,
	INDEX(user_id),INDEX(project_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;